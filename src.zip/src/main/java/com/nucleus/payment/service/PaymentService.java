package com.nucleus.payment.service;

public interface PaymentService {
}
