package com.nucleus.payment.dao;

public interface PaymentDAO {

}
