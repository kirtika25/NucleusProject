package com.nucleus.repaymentschedule.service;

import com.nucleus.loanapplications.model.LoanApplications;
import com.nucleus.repaymentschedule.model.RepaymentSchedule;

import java.util.List;

public interface RepaymentScheduleService {

    public int addRepaymentSchedule(LoanApplications loanApplication) ;

}
