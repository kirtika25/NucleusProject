package com.nucleus.repaymentschedule.dao;

import com.nucleus.repaymentschedule.model.RepaymentSchedule;

import java.util.List;


public interface RepaymentScheduleDAO {
    public int addRepaymentSchedule(RepaymentSchedule repaymentSchedule);
}


