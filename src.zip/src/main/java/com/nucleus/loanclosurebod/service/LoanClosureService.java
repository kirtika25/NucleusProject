package com.nucleus.loanclosurebod.service;

/**
 * This is a Service Interface that declares the functionality
 * of the LoanClosureServiceImpl Class.
 */
public interface LoanClosureService {

    int loanClosureBod();

}