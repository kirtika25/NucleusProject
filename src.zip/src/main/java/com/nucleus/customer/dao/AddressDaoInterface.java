package com.nucleus.customer.dao;

import com.nucleus.customer.model.Address;

public interface AddressDaoInterface {
    boolean insertAddress(Address address);
}
