package com.nucleus.login.logindetails;

public interface LoginDetails {

    public String getUserName();
}
